﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace semestralka.utils
{
    public static class Constants {
        public const string ERROR = "CHYBA !";
        public const string ERROR_SOMEWHERE = "Niekde nastala chyba !";
    }
}
